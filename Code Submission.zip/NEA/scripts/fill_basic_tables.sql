INSERT INTO FileType(FileType) VALUES ('Text'), ('Whiteboard');
INSERT INTO Permissions(PermissionType) VALUES ('Read'), ('Write');
